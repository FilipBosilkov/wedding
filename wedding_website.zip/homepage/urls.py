from django.urls import path
from . import views

urlpatterns = [

    path('send-message/', views.send_message, name='send_message'),
    path('api/login/', views.login, name='login_guest'),
    # This will be your home page for the homepage app
    
]
