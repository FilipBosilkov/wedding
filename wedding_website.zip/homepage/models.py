from django.db import models


class RegistryItem(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    available = models.BooleanField(default=True)
    picture = models.ImageField(upload_to='images/')

    def __str__(self):
        return self.name


# Create your models here.
class Table(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Guest(models.Model):
    guestId = models.IntegerField(null=False)
    firstName = models.CharField(max_length=255)
    lastName = models.CharField(max_length=255)
    picture = models.ImageField(upload_to='guest_pictures/')
    password = models.CharField(max_length=255)
    table = models.ForeignKey(Table, on_delete=models.CASCADE)

    def __str__(self):
        return self.firstName + self.lastName


class Message(models.Model):
    id = models.AutoField(primary_key=True)
    guest = models.ForeignKey(Guest, on_delete=models.CASCADE, related_name='messages')  # Foreign key to Guest
    text = models.TextField()
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.id


class News(models.Model):
    title = models.CharField(max_length=255)
    image = models.ImageField(upload_to='images/')
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class GalleryImage(models.Model):
    title = models.CharField(max_length=255, blank=True)
    description = models.TextField(blank=True)
    image = models.ImageField(upload_to='gallery/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title if self.title else "Untitled Image"
