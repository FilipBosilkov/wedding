from django.shortcuts import render, redirect
from .forms import MessageForm, LogInForm
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Guest


# Create your views here.

def index(request):
    return render(request, 'static/index.html')

def login(request):
    if request.method == 'POST':
        form = LogInForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            password = form.cleaned_data.get('password')

            try:
                guest = Guest.objects.get(name=name, password=password)
                return redirect('home', guestId=guest.guestId)
            except Guest.DoesNotExist:
                form.add_error(None, 'Invalid name or code')
    else:
        form = LogInForm()

    return render(request, 'homepage/home.html', {'form': form})


def send_message(request):
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('message_sent')
    else:
        form = MessageForm()


def home(request):
    return render(request, 'homepage/home.html', {'form': MessageForm()})


@api_view(['POST'])
def api_login(request):
    """
    This view will handle login via API for React frontend.
    """
    name = request.data.get('name')
    password = request.data.get('password')

    try:
        guest = Guest.objects.get(name=name, password=password)
        return Response({'message': 'Login successful', 'guestId': guest.id}, status=status.HTTP_200_OK)
    except Guest.DoesNotExist:
        return Response({'error': 'Invalid name or password'}, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
def api_send_message(request):
    """
    This view will handle message submission via API for React frontend.
    """
    form = MessageForm(request.data)
    if form.is_valid():
        form.save()
        return Response({'message': 'Message sent successfully!'}, status=status.HTTP_201_CREATED)
    else:
        return Response(form.errors, status=status.HTTP_400_BAD_REQUEST)
