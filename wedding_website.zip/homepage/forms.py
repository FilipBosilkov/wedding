from django import forms
from .models import Message


class LogInForm(forms.Form):
    name = forms.CharField(max_length=120)
    password = forms.CharField(max_length=120)


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ['text']  # Fields the guest will fill
        widgets = {
            'message': forms.Textarea(attrs={'rows': 4}),  # Resize the message field
        }
